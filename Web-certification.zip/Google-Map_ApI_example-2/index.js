// Initialize and add the map
let map;

async function initMap() {
  // The location of Uluru
  const position = { lat: 28.58281043282418, lng: 77.31373526136883 };
  // Request needed libraries.
  //@ts-ignore
  const { Map } = await google.maps.importLibrary("maps");
  const { AdvancedMarkerView } = await google.map.importLibrary("marker");

  // The map, centered at Uluru
  map = new Map(document.getElementById("map"), {
    zoom: 4,
    center: position,
    mapId: "DEMO_MAP_ID",
  });

  // The marker, positioned at Edureka!
  const marker = new AdvancedMarkerView({
    map: map,
    position: position,
    title: "Edureka!",
  });
}

initMap();